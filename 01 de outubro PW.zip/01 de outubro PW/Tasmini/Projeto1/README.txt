Sejam bem vindos ao novo ano letivo 
Votos de muito sucesso e conclusão dos vossos estudos!
Santarém, 24 de setembro de 2024!